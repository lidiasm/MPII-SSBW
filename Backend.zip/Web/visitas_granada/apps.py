from django.apps import AppConfig


class VisitasGranadaConfig(AppConfig):
    name = 'visitas_granada'
