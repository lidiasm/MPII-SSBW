from django.contrib import admin
from .models import Visita, Comentario

admin.site.register(Visita)
admin.site.register(Comentario)